const fs = require('fs')
const path = require('path')
const axios = require('axios')
const cases = require('../cases')

// console.log(cases)

let results = []  // 用于记录测试结果
function runCases(url){
    if(!cases){
        results.push('No cases found. Please build some cases in cases.js file.')
        return Promise.resolve()
    }

    const caseKeys = Object.keys(cases)
    const casePromises = caseKeys.map( key => {
        let {input, output} = cases[key]
        // console.log(`测试用例${key}`, input, output)

        return new Promise((resolve, reject)=>{
            // console.log('发起网络请求', key)
            axios.post(url, input, {
                validateStatus: function (status) {
                    return status >= 200 && status < 500
                  },
            }).then((response)=>{
                let {status, data} = response
                // console.log('网络请求结束', key, status, data)
                if(checkResult(response, output)){
                    results.push(`The case - ${key} success.\n`)
                }else{
                    results.push(`The case - ${key} failure. More info below:`)
                    results.push(`Input: ${JSON.stringify(input)}`)
                    results.push(`Expect: ${JSON.stringify(output)}`)
                    results.push(`Response: Status - ${status} Result - ${JSON.stringify(data)}\n`)
                }
                resolve()
            }).catch(err=>{
                reject(err)
            })
        })
    })

    return Promise.all(casePromises)
}

function checkResult(response, output){
    let {status, data} = response
    let {status: s, msg} = output
    if(status == s && (
        data['success'] === msg ||
        data['error'] === msg
    )){
        return true
    }

    return false
}

function writeResultToFile(){
    return new Promise((resolve, reject)=>{
        fs.writeFile(path.join(__dirname, '../result.txt'), results.join('\n'), (err)=>{
            if(err){
                reject(err)
            }else{
                resolve()
            }
        })
    })
}


function executeTest(url){
    results = []
    // console.log('准备开始测试了:', url)
    return runCases(url).then(()=>{
        // console.log('将结果存起来')
        return writeResultToFile()
    })
}

module.exports = executeTest