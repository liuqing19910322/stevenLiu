const program = require('commander');
const executeTest = require('./src')

// http://preview.airwallex.com:30001/bank

program
  .option('-e, --endpoint [url]', 'Enter your endpoint url')
  .parse(process.argv);

const url = (program.endpoint === false) ? '' : `${program.endpoint}`;
console.log(`The endpoint url is ${url}`, typeof url);

if(!url){
    console.log('Please enter endpoint url.')
    return
}

executeTest(url).then(()=>{
    console.log('The test is completed.\nYou can get the result from result.txt in this project dictionary.')
}).catch((err)=>{
    console.error('Ops, some errors has occured. The error detail:', err)
})


process.on('uncaughtException', (err) => {
    console.error(`Fatal error, uncaughtException：${err}\n`)
});

