## Environment
**Node is Required**
> You can visit [NodeJS](https://nodejs.org/en/) to install node environment

## About cases
You can add test cases in file `cases.js`, like this:
```js
"case1": {
    "input": {
        "payment_method": "SWIFT",
        "bank_country_code": "US",
        "account_name": "John Smith",
        "account_number": "123",
        "swift_code": "ICBCUSBJ",
        "aba": "11122233A"
    },
    "output": {
        "status": "200",
        "msg": "Bank details saved"
    }
}
```
`case1` is the case name. `input` is your test input. `output` is the data structure which describe your test expection.
All test result info will write into file `result.txt`. You can scan info in there.

## How to use

* Install dependencies
```js
npm install
```

* Run test via commander
```js
node index.js -e http://preview.airwallex.com:30001/bank
```
`-e` is required. You have to assign a url to it. Otherwise, test will fail.


`node index.js --help` will list more options.