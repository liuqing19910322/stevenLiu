module.exports = {
    "case1": {
        "input": {
            "payment_method": "SWIFT",
            "bank_country_code": "US",
            "account_name": "John Smith",
            "account_number": "123",
            "swift_code": "ICBCUSBJ",
            "aba": "11122233A"
        },
        "output": {
            "status": "200",
            "msg": "Bank details saved"
        }
    },
    "case2": {
        "input": {
            "payment_method": "SWIFT",
            "bank_country_code": "AU",
            "account_name": "John Smith",
            "account_number": "1",
            "swift_code": "ICBCUSBJ",
            "aba": "11122233A"
        },
        "output": {
            "status": "400",
            "msg": "One \'error\'"
        }
    }
}